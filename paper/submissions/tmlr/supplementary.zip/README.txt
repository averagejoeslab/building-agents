Supplementary material, anonymized for review.
  supplementary.pdf   Appendix B: the evidence for every assignment in the deconstruction (Section 5)
  evidence/           the source of Appendix B: one Markdown file per harness, and the brief the deconstruction followed
  minimal/            the five minimal harnesses of Appendix A, one primitive at a time
