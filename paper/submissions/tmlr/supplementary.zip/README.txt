Supplementary material, anonymized for review.
  supplementary.pdf   Appendix C: the evidence for every assignment in the deconstruction (Section 5)
  evidence/           the source of Appendix C: one Markdown file per harness, and the brief the deconstruction followed
  minimal/            the five minimal harnesses of Appendix A, one primitive at a time
